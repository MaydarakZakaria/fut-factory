<?php
/**
 * Class Context
 */
class Context extends ContextCore {

}
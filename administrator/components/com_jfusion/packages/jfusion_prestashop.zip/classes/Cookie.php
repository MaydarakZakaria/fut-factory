<?php
/**
 * Class Cookie
 */
class Cookie extends CookieCore {

}
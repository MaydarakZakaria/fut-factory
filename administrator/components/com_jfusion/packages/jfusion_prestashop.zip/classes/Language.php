<?php
/**
 * Class Language
 */
class Language extends LanguageCore {

}
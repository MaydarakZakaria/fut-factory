<?php
/**
 * Class Customer
 */
class Customer extends CustomerCore {

}
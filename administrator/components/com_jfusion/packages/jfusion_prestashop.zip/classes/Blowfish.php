<?php
/**
 * Class Blowfish
 */
class Blowfish extends BlowfishCore {

}
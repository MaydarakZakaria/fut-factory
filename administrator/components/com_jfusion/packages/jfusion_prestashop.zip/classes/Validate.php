<?php
/**
 * Class Validate
 */
class Validate extends ValidateCore {

}
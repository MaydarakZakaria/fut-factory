<?php
/**
 * Class State
 */
class State extends StateCore {

}